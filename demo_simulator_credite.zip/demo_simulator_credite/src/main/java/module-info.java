module com.example.demo_simulator_credite {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.demo_simulator_credite to javafx.fxml;
    exports com.example.demo_simulator_credite;
}